export interface AuthTokenResponse {
  token: string;
}
