export interface DialogData {
  title: string;
  message: string;
  yesBtnText?: string;
  noBtnText?: string;
}
