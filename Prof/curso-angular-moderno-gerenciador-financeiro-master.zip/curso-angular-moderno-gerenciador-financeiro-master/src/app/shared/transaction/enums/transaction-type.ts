export enum TransactionType {
  INCOME = 'income',
  OUTCOME = 'outcome'
}
