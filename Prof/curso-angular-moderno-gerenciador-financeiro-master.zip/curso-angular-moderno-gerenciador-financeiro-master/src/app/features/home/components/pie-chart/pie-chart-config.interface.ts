export interface PieChartConfig {
  labels: string[],
  dataLabel: string;
  data: number[]
}
